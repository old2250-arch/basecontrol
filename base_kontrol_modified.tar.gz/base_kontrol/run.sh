#!/bin/bash

if [ -f ".env" ]; then
    set -a
    source .env
    set +a
fi

CF_TOKEN="${CF_TUNNEL_TOKEN}"
PORT="${PORT:-3000}"
HOST="${HOST:-0.0.0.0}"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
RESET='\033[0m'

clear
echo -e "${CYAN}🚀 Starting Server...${RESET}"

detect_main_file() {
    if [ -f "package.json" ]; then
        local pkg_main
        pkg_main=$(node -p "require('./package.json').main || ''" 2>/dev/null)
        if [ -n "$pkg_main" ] && [ -f "$pkg_main" ]; then
            echo "$pkg_main"
            return
        fi
    fi
    for f in index.js app.js server.js bot.js main.js sync.js; do
        [ -f "$f" ] && { echo "$f"; return; }
    done
    echo ""
}

MAIN_FILE="${MAIN_FILE:-$(detect_main_file)}"

if [ -z "$MAIN_FILE" ] || [ ! -f "$MAIN_FILE" ]; then
    echo -e "${RED}✗ Tidak menemukan file utama.${RESET}"
    echo -e "${RED}  Set manual lewat .env: MAIN_FILE=namafile.js${RESET}"
    exit 1
fi
echo -e "${GREEN}✓ Main file: ${MAIN_FILE}${RESET}"

detect_arch() {
    case "$(uname -m)" in
        x86_64) echo "amd64" ;;
        aarch64|arm64) echo "arm64" ;;
        armv7l|armv6l) echo "arm" ;;
        *) echo "" ;;
    esac
}

if [ ! -f "./cloudflared" ] && [ -n "$CF_TOKEN" ]; then
    CF_ARCH=$(detect_arch)
    if [ -z "$CF_ARCH" ]; then
        echo -e "${RED}✗ Arsitektur tidak dikenali${RESET}"
    else
        echo -e "${YELLOW}Downloading cloudflared (${CF_ARCH})...${RESET}"
        curl -L -# "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}" -o cloudflared
        chmod +x cloudflared
        echo -e "${GREEN}✓ cloudflared downloaded${RESET}"
    fi
fi

if [ -n "$CF_TOKEN" ] && [ -f "./cloudflared" ]; then
    echo -e "${YELLOW}Connecting Cloudflare Tunnel...${RESET}"
    ./cloudflared tunnel run --token "$CF_TOKEN" > /tmp/cf_tunnel.log 2>&1 &
    sleep 3
    if pgrep -f "cloudflared tunnel run" > /dev/null; then
        echo -e "${GREEN}✓ Tunnel is running${RESET}"
    else
        echo -e "${RED}✗ Failed to start tunnel. Check /tmp/cf_tunnel.log${RESET}"
    fi
else
    echo -e "${YELLOW}CF_TUNNEL_TOKEN tidak diset, tunnel dilewati${RESET}"
fi

if [ -f "package.json" ]; then
    echo -e "${YELLOW}Installing npm dependencies...${RESET}"
    npm install --production
    echo -e "${GREEN}✓ Dependencies installed${RESET}"
fi

echo -e "${GREEN}Starting Node.js application (${MAIN_FILE}) on ${HOST}:${PORT}...${RESET}"
export PORT
export HOST
exec node "$MAIN_FILE"
