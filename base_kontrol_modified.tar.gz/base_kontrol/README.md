# Backend Kontrol + Auto Backup

Server Node.js dengan Socket.io, Telegram Bot, sistem order, dan auto-backup terintegrasi.

## Fitur

- **Multi-role User Management**: Developer, Owner, Reseller, Member
- **Payment Gateway**: Integrasi Pakasir QRIS
- **Device Control**: Remote Android device control via Socket.io
- **Telegram Bot**: Notifikasi otomatis
- **Auto Backup**: Backup otomatis setiap jam ke folder `backups/`
- **Cloudflare Tunnel**: Support untuk expose server ke internet

## Setup

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Konfigurasi `.env`**:
   ```
   PORT=3000
   HOST=0.0.0.0
   CF_TUNNEL_TOKEN=your_cloudflare_token_here
   MAIN_FILE=sync.js
   ```

3. **Edit Telegram Bot Token** di `sync.js`:
   ```javascript
   const BOT_TOKEN = 'your_bot_token'
   const OWNER_ID  = your_telegram_id
   ```

4. **Edit Pakasir API** di `sync.js`:
   ```javascript
   const PAKASIR_PROJECT = 'your_project_name'
   const PAKASIR_API_KEY = 'your_api_key'
   ```

## Cara Menjalankan

### Opsi 1: Direct Node.js
```bash
node sync.js
```

### Opsi 2: Dengan run.sh (recommended)
```bash
./run.sh
```

Script `run.sh` akan otomatis:
- Deteksi file utama (sync.js)
- Download Cloudflared (jika CF_TUNNEL_TOKEN ada)
- Install dependencies
- Start server

## Auto Backup

Backup otomatis berjalan:
- **Pertama kali**: 5 detik setelah server start
- **Jadwal**: Setiap jam (0 * * * *)
- **File yang di-backup**: 
  - accounts.json
  - device.json
  - orders.json
  - helpers.json

Backup disimpan di folder `backups/` dengan format: `backup-YYYY-MM-DDTHH-MM-SS.zip`

## Struktur Folder

```
/root/workspace/8578138028/
├── sync.js              # Main server file
├── package.json         # Dependencies
├── .env                 # Environment variables
├── run.sh               # Startup script
├── accounts.json        # User accounts data
├── device.json          # Device mapping
├── orders.json          # Payment orders
├── helpers.json         # Helper orders
├── backups/             # Auto-backup folder
└── frontend/            # HTML files
    ├── login.html
    ├── dashboard.html
    ├── adminpanel.html
    ├── order.html
    └── helper.html
```

## API Endpoints

### Auth
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `GET /api/me` - Get current user info

### Admin
- `GET /api/admin/accounts` - List accounts
- `POST /api/admin/create-account` - Create new account
- `DELETE /api/admin/accounts/:username` - Delete account
- `GET /api/admin/quota` - Check quota

### Order
- `POST /api/order/create` - Create payment order
- `GET /api/order/status/:invoiceId` - Check payment status
- `POST /api/order/complete` - Complete order & create account

## Role Hierarchy

1. **Developer** - Full access, unlimited quota
2. **Owner** - Can create Reseller & Member
3. **Reseller** - Can create Member only
4. **Member** - End user

## Notes

- Server default port: 3000 (bisa diubah di `.env`)
- Backup file akan terus bertambah, hapus manual file lama jika perlu
- Cloudflare Tunnel opsional, server tetap jalan tanpa CF
