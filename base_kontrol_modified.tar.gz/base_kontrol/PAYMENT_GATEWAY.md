# Payment Gateway - DigitalPedia

Backend NexusRAT menggunakan **DigitalPedia** untuk payment gateway QRIS.

## Configuration

Edit `sync.js` line 31-32:

```javascript
const DIGITALPEDIA_API_KEY = 'YOUR_API_KEY';
const DIGITALPEDIA_BASE = 'https://pay.digitalpedia.web.id';
```

Ganti `YOUR_API_KEY` dengan API key dari DigitalPedia.

---

## API Endpoints

### 1. Create Deposit (QRIS)

**Endpoint:** `POST /api/deposit/create`

**Request:**
```javascript
{
  "amount": 50000
}
```

**Response:**
```javascript
{
  "success": true,
  "deposit": {
    "id": "DP17500001234567",
    "amount": 50000,
    "fee": 0,
    "total_payment": 50000,
    "qr_image": "https://imgbb.46dhygfadgs.png",
    "status": "pending",
    "expired_at": "2026-06-17T11:00:00.000Z"
  }
}
```

---

### 2. Check Status

**Endpoint:** `POST /api/deposit/status`

**Request:**
```javascript
{
  "deposit_id": "DP17500001234567"
}
```

**Response:**
```javascript
// Pending
{
  "success": true,
  "status": "pending",
  "message": "Menunggu pembayaran"
}

// Success
{
  "success": true,
  "status": "success",
  "message": "Deposit berhasil! Saldo bertambah."
}

// Expired
{
  "success": true,
  "status": "expired",
  "message": "Deposit expired"
}
```

---

### 3. Cancel Deposit

**Endpoint:** `POST /api/deposit/cancel`

**Request:**
```javascript
{
  "deposit_id": "DP17500001234567"
}
```

**Response:**
```javascript
{
  "success": true,
  "message": "Deposit berhasil dibatalkan"
}
```

---

## Implementation

### Functions di sync.js

#### `createQrisDigitalPedia({ amount })`
- Buat deposit QRIS baru
- Return: depositId, qrString, amount, fee, total, expiresAt

#### `checkStatusDigitalPedia({ depositId })`
- Cek status pembayaran
- Return: status (pending/success/expired), message, isPaid

---

## Usage Flow

1. **Create Order** → User pilih paket → Backend call `createQrisDigitalPedia()`
2. **Show QR** → Frontend display `qr_image` ke user
3. **Check Status** → Frontend polling `checkStatusDigitalPedia()` setiap 3-5 detik
4. **Complete** → Jika `status === 'success'` → Create account

---

## Error Handling

```javascript
try {
  const qris = await createQrisDigitalPedia({ amount: 50000 });
  // Show QR to user
} catch (error) {
  console.error('[DIGITALPEDIA] Error:', error.message);
  // Show error to user
}
```

---

## Notes

- Minimal deposit: Rp 500
- QR code expired sesuai response `expired_at`
- Status `expired` tidak bisa di-cancel
- API key wajib di header: `x-api-key`
