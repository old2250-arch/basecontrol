#!/bin/bash
cd /root/workspace/8578138028
./run.sh
